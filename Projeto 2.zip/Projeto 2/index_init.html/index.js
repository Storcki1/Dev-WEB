// let botao = document.getElementById("titulo").textContent = "Mudamos o texto!"

// let itemId = "tecla_gato"
//botao.onclick = play_som

function play_som(itemId){
    document.getElementById(itemId).play()
}

let listaDeTeclas = document.querySelectorAll(".tecla")

for (let contador = 0; contador < listaDeTeclas.length; contador++){
    let botao = listaDeTeclas[contador]
    let itemId = listaDeTeclas[contador].classList[1]

    botao.onclick = function(){
        play_som(itemId)
    }
        
}



